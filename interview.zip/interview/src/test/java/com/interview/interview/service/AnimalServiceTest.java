package com.interview.interview.service;

import com.interview.interview.repository.AnimalRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class AnimalServiceTest {
    @Mock
private AnimalRepository animalRepository;
    private  AnimalService underTest;

    @BeforeEach
    void setUp() {
underTest = new AnimalService(animalRepository);
    }

    @Test
    void canGetAllAnimals() {
        // when
        underTest.getAllAnimals();
        //then
        verify(animalRepository).findAll();
    }
}