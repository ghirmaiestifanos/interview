package com.interview.interview.controller;

import com.interview.interview.model.Animal;
import com.interview.interview.service.AnimalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("dog.ceo/api/breeds/list/all")
public class AnimalController {
    @Autowired
    private AnimalService animalService;
    @GetMapping
    public Iterable<Animal> getAll() {
        return animalService.getAllAnimals();
    }
}
