package com.interview.interview.service;

import com.interview.interview.model.Animal;
import com.interview.interview.repository.AnimalRepository;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.List;

@Service
@Transactional
@AllArgsConstructor
@NoArgsConstructor
public class AnimalService {
    @Autowired
    private AnimalRepository animalRepository;

    public Iterable<Animal> getAllAnimals(){
     return  animalRepository.findAll();

    }
}
